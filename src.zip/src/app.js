import React, {Component} from 'react'; // importing premade stuff
import Urbit from '@urbit/http-api';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'react-day-picker/lib/style.css';
import TextareaAutosize from 'react-textarea-autosize';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Stack from 'react-bootstrap/Stack';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import ToastContainer from 'react-bootstrap/ToastContainer';
import Toast from 'react-bootstrap/Toast';
import Spinner from 'react-bootstrap/Spinner';
import CloseButton from 'react-bootstrap/CloseButton';
import Modal from 'react-bootstrap/Modal';
import DayPickerInput from 'react-day-picker/DayPickerInput';
import endOfDay from 'date-fns/endOfDay';
import startOfDay from 'date-fns/startOfDay';
import {BottomScrollListener} from 'react-bottom-scroll-listener';
import { FormProvider, useForm } from 'react-hook-form';


class App extends Component {
  state = {
    items: [], // list of bookmarks
    drafts: {}, // unsaved edited items
    newDraft: {}, // unsaved new item
    results: [], // search results
    searchTime: null, // time of last search
    searchStart: null, // search start date
    searchEnd: null, // search end date
    resultStart: null, // date search results start
    resultEnd: null, // date search results end
    latestUpdate: null, // most recent update
    itemToDelete: null, // deletion target for confirmation modal
    status: null, // connection status (con, try, err)
    errorCount: 0,
    errors: new Map(), // list of error msgs for display
  };

  componentDidMount() { // typical lifecycle method - sets up initial state, sets up urbit airlock
    window.urbit = new Urbit(""); // imported from urbit http-api; it figures out empty url string
    window.urbit.ship = window.ship; // session.js sets window.ship=@p so this line includes @p w all eyre requests
    window.urbit.onOpen = () => this.setState({status: "con"});
    window.urbit.onRetry = () => this.setState({status: "try"});
    window.urbit.onError = (err) => this.setState({status: "err"});
    this.init();
  };

  init = () => {
    this.getEntries()
    .then(
      (result) => { // if getEntries works, gets updates, subs
        this.handleUpdate(result);
        this.setState({latestUpdate: result.time});
        this.subscribe()
      },
      (err) => { // if scry fails, puts error msg in map and sets status
        this.setErrorMsg("Connection failed");
        this.setState({status: "err"})
      }
    )
  };

  reconnect = () => {
    window.urbit.reset();
    const latest = this.state.latestUpdate;
    if (latest === null) {
      this.init();
    } else {
      this.getUpdates()
      .then(
        (result) => {
          result.logs.map(i => this.handleUpdate(i));
          this.subscribe()
        },
        (err) => {
          this.setErrorMsg("Connection failed");
          this.setState({status: "err"})
        }
      )
    }
  };

  getUpdates = async () => {
    const {latestUpdate: latest} = this.state;
    const since = (latest === null) ? Date.now() : latest;
    const path = `/updates/since/${since}`;
    return window.urbit.scry({
      app: "cue",
      path: path
    })
  };

  getEntries = async () => { // gets 10 entries
    const {entries: e} = this.state;
    const before = (e.length === 0) ? Date.now() : e[e.length - 1].id;
    const max = 10;
    const path = `/entries/before/${before}/${max}`;
    return window.urbit.scry({
      app: "cue",
      path: path
    })
  };

  moreEntries = () => { // gets 10 entries when user scrolls to bottom
    this.getEntries()
    .then(
      (result) => {this.handleUpdate(result)},
      (err) => {this.setErrorMsg("Fetching more entries failed")}
    )
  };

  subscribe = () => { //subscribes to the /updates path of demo app
    try {
      window.urbit.subscribe({
        app: "cue",
        path: "/updates",
        event: this.handleUpdate,
        err: ()=>this.setErrorMsg("Subscription rejected"),
        quit: ()=>this.setErrorMsg("Kicked from subscription")
      })
    } catch {
      this.setErrorMsg("Subscription failed")
    }
  };

  delete = (id) => {
    window.urbit.poke({
      app: "cue",
      mark: "cue-action",
      json: {"del": {"id": id}},
      onError: ()=>this.setErrorMsg("Deletion rejected")
    })
    this.setState({rmModalShow: false, itemToDelete: null})
  };

  read = (id) => {
    window.urbit.poke({
      app: "cue",
      mark: "cue-action",
      json: {"read": {"id": id}},
      onError: ()=>this.setErrorMsg("Mark read failed")
    })
  };

  publish = (id) => {
    window.urbit.poke({
      app: "cue",
      mark: "cue-action",
      json: {"publish": {"id": id}},
      onError: ()=>this.setErrorMsg("Mark public failed")
    })
  };

  submitEdit = (id, title, tags, link, done, share) => {
    if (link !== null) {
      window.urbit.poke({
        app: "cue",
        mark: "cue-action",
        json: {"edit": {"id": id, "title": title, "tags": tags, "link": link, "done": done, "share": share}},
        onError: ()=>this.setErrorMsg("Edit rejected")
      })
    } else this.cancelEdit(id)
  };

  submitNew = (id, title, tags, link, done, share) => {
    window.urbit.poke({
      app: "cue",
      mark: "cue-action",
      json: {"add": {"id": id, "title": title, "tag": tags, "link": link, "done": done, "share": share}},
      onSuccess: ()=>this.setState({newDraft: {}}),
      onError: ()=>this.setErrorMsg("New Item rejected")
    })
  };

  getSearch = async () => { // original date search
    const {
      searchStart: ss,
      searchEnd: se,
      latestUpdate: lu
    } = this.state;
    if (lu !== null && ss !== null && se !== null) { //scries if dates valid and gives results
      let start = ss.getTime();
      let end = se.getTime();
      if (start < 0) start = 0;
      if (end < 0) end = 0;
      const path = `/entries/between/${start}/${end}`;
      window.urbit.scry({
        app: "cue",
        path: path
      })
      .then(
        (result) => {
          this.setState({
            searchTime: result.time,
            searchStart: null,
            searchEnd: null,
            resultStart: ss,
            resultEnd: se,
            results: result.entries
          })
        },
        (err) => {
          this.setErrorMsg("Search failed")
        }
      )
    } else {
      (lu !== null) && this.setErrorMsg("Searh failed") // what is latestUpdate? search fail if no results?
    }
  };

  getTagSearch = async () => { // new tag search
    const {
      searchTag: tag,
      latestUpdate: lu
    } = this.state;
    if (tag !== null) {
      let start = tag;
      const path = `/entries/has/${tag}`;
      window.urbit.scry({
        app: "cue",
        path: path
      })
      .then(
        (result) => {
          this.setState({
            searchTag: null, // sets tag to null after success
            // resultStart: ss, I don't think these are needed but not sure
            // resultEnd: se,
            results: result.entries
          })
        },
        (err) => {
          this.setErrorMsg("Search failed")
        }
      )
    } else {
      (lu !== null) && this.setErrorMsg("Searh failed")
    }
  };

  spot = (id, data) => {
    let low = 0
    let high = data.length;
    while (low < high) {
      let mid = (low + high) >>> 1;
      if (data[mid].id > id) low = mid + 1;
      else high = mid;
    }
    return low;
  };

  inSearch = (id, time) => {
    const {
      searchTime,
      resultStart,
      resultEnd
    } = this.state;
    return (
      searchTime !== null &&
        time >= searchTime &&
        resultStart.getTime() <= id &&
        resultEnd.getTime() >= id
    )
  };

  handleUpdate = (upd) => { // applies results to the state
    const {entries, drafts, results, latestUpdate} = this.state;
    if (upd.time !== latestUpdate) {
      if ("entries" in upd) {
        this.setState({entries: entries.concat(upd.entries)})
      } else if ("add" in upd) {
        const {time, add} = upd;
        const eInd = this.spot(add.id, entries);
        const rInd = this.spot(add.id, results);
        const toE = (entries.length === 0) ||
              (add.id > entries[entries.length - 1].id);
        const toR = (this.inSearch(add.id, time));
        toE && entries.splice(eInd, 0, add);
        toR && results.splice(rInd, 0, add);
        this.setState({
          ...(toE && {entries: entries}),
          ...(toR && {results: results}),
          latestUpdate: time
        })
      } else if ("edit" in upd) {
        const {time, edit} = upd;
        const eInd = entries.findIndex(e => e.id === edit.id);
        const rInd = results.findIndex(e => e.id === edit.id);
        const toE = eInd !== -1;
        const toR = rInd !== -1 && this.inSearch(edit.id, time);
        if (toE) entries[eInd] = edit;
        if (toR) results[rInd] = edit;
        (toE || toR) && delete drafts[edit.id];
        this.setState({
          ...(toE && {entries: entries}),
          ...(toR && {results: results}),
          ...((toE || toR) && {drafts: drafts}),
          latestUpdate: time
        })
      } else if ("del" in upd) {
        const {time, del} = upd;
        const eInd = entries.findIndex(e => e.id === del.id);
        const rInd = results.findIndex(e => e.id === del.id);
        const toE = eInd !== -1;
        const toR = (this.inSearch(del.id, time)) && rInd !== -1;
        (toE) && entries.splice(eInd, 1);
        (toR) && results.splice(rInd, 1);
        (toE || toR) && delete drafts[del.id];
        this.setState({
          ...(toE && {entries: entries}),
          ...(toR && {results: results}),
          ...((toE || toR) && {drafts: drafts}),
          latestUpdate: time
        })
      }
    }
  };

  cancelEdit = (id) => {
    const {drafts} = this.state;
    delete drafts[id];
    this.setState({drafts: drafts})
  };

  saveDraft = (id, text) => {
    const {drafts} = this.state;
    drafts[id] = text;
    this.setState({drafts: drafts})
  };

  setEdit = (id) => {
    const {drafts} = this.state;
    if (!(id in drafts)) {
      drafts[id] = null;
      this.setState({drafts: drafts})
    }
  };
 
  closeRmModal = () => {
    this.setState({itemToDelete: null})
  };

  openRmModal = (id) => {
    this.setState({itemToDelete: id})
  };

  rmModal = () => {
    const id = this.state.itemToDelete;
    if (id !== null) {
      return (
        <Modal
          size="lg"
          centered
          show={(id !== null)}
          onHide={()=>this.closeRmModal()}
        >
          <Modal.Header closeButton>
            <Modal.Title>Confirm Delete</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            Are you sure you want to delete this item?
          </Modal.Body>
          <Modal.Footer>
            <Button
              variant="outline-danger"
              onClick={()=>this.delete(id)}
            >
              Delete
            </Button>
          </Modal.Footer>
        </Modal>
      )
    }
  };

  editBox = (id, link, draft) => {
    return (
      <TextareaAutosize
        className="w-100 form-control"
        value={(draft === null) ? link : draft}
        onChange={(i) => this.saveDraft(id, i.target.value)}
      />
    );
  };

  printItem = ({id, title, tags, link, done, share}) => {
    const {drafts} = this.state;
    const edit = (id in drafts);
    const draft = (id in drafts) ? drafts[id] : null;
    const reg = /(?:\r?\n[ \t]*){2,}(?!\s*$)/;
    let d = new Date(id);
    return (
      <Card key={id}>
        <Card.Header
          className="fs-4 d-flex align-items-center justify-content-between"
        >
          {d.toLocaleString()}
          <CloseButton
            className="fs-6"
            onClick={() => (edit) ? this.cancelEdit(id) : this.openRmModal(id)}
          />
        </Card.Header>
        <Card.Body onClick={()=>this.setEdit(id)}>
          {(edit)
           ? this.editBox(id, title, link, done, share, draft)
           : link.split(reg).map((i, ind) => <p key={ind}>{i}</p>)
          }
        </Card.Body>
        {(edit) &&
          <Button
            variant="outline-primary"
            className="mx-3 mb-3"
            onClick={()=>this.submitEdit(id, draft)}
          >
            Submit
          </Button>
        }
      </Card>
    )
  };

  setSearchStart = (when) => {
    if (when instanceof Date && !isNaN(when)) {
      const date = startOfDay(when);
      this.setState({searchStart: date})
    } else this.setState({searchStart: null})
  };

  setSearchEnd = (when) => {
    if (when instanceof Date && !isNaN(when)) {
      const date = endOfDay(when);
      this.setState({searchEnd: date})
    } else this.setState({searchEnd: null})
  };

  searcher = () => { // original date search
    const {
      searchStart: ss,
      searchEnd: se,
      resultStart: rs,
      resultEnd: re
    } = this.state;  // alias variables? and set state to inputs? Defines relevant parts of state for this operation?
    return (
      <Stack gap={5}>
        <div className="d-flex justify-content-between">
          <div
            className="me-2 d-flex justify-content-start align-items-center flex-wrap"
          >
            <DayPickerInput
              value={ss}
              placeholder="FROM  YYYY-M-D"
              onDayChange={day => this.setSearchStart(day)}
              style={{margin: "5px 5px 5px 0"}}
            />
            <DayPickerInput
              value={se}
              placeholder="TO  YYYY-M-D"
              onDayChange={day => this.setSearchEnd(day)}
              style={{margin: "5px 5px 5px 0"}}
            />
          </div>
          <Button // why is the button outside of the divider for date search?
            className="w-20"
            variant={
              (ss === null || se === null)
                ? "outline-secondary" : "outline-primary"
            }
            disabled={ss === null || se === null} // if search start and end are empty, button is disabled
            onClick={()=>this.getSearch()} // on click moves above? state? into getSearch function L176 where scry happens
          >
            Search
          </Button>
        </div>
        { (rs !== null && re !== null) && // first divider is for input, second section is results
            <div className="fs-4">
              Results for {rs.toLocaleDateString()} to {re.toLocaleDateString()}
            </div>
        }
      </Stack>
    )
  };

  tagsearcher = () => { // new tag search
    const {
      searchTag: tag,
      resultStart: rs,
      resultEnd: re
    } = this.state;
    return (
      <Stack gap={5}>
        <div className="d-flex justify-content-between">
          <div
            className="me-2 d-flex justify-content-start align-items-center flex-wrap"
          >
            <TextareaAutosize // clearly daypickerinput is not needed, but need to manifest a text field for tag input
          placeholder="NOTEBOOK"
          value={tag}
          onChange={tag => this.setSearchTag(tag)}
            />
          </div>
          <Button
            className="w-20"
            variant={
              (tag === null)
                ? "outline-secondary" : "outline-primary"
            }
            disabled={tag === null} //disabled if no search term
            onClick={()=>this.getTagSearch()}
          >
            Search
          </Button>
        </div>
        { (rs !== null && re !== null) &&
            <div className="fs-4">
              Results for {rs.toLocaleDateString()} to {re.toLocaleDateString()}
            </div>
        }
      </Stack>
    )
  };

  setErrorMsg = (msg) => {
    const {errors, errorCount} = this.state;
    const id = errorCount + 1;
    this.setState({
      errors: errors.set(id, msg),
      errorCount: id
    })
  };

  rmErrorMsg = (id) => {
    const {errors} = this.state;
    errors.delete(id);
    this.setState({
      errors: errors,
    })
  };

  errorMsg = (id, msg) => {
    return (
      <Toast
        key={id}
        className="ms-auto"
        onClose={() => this.rmErrorMsg(id)}
        show={true}
        delay={3000}
        autohide
        style={{width: "fit-content"}}
      >
        <Toast.Header className="d-flex justify-content-between">
          {msg}
        </Toast.Header>
      </Toast>
    )
  };

  status = () => {
    const {status, errors} = this.state;
    return (
      <ToastContainer
        style={{
          position: "sticky",
          bottom: 0,
          width: "100%",
          zIndex: 50
        }}
      >
        {[...errors].map((e) => this.errorMsg(e[0],e[1]))}
        <Toast
          bg={(status === "try") ? "warning" : "danger"}
          className="w-100"
          show={(status === "try" || status === "err")}
        >
          <Toast.Body
            className="d-flex justify-content-center align-items-center"
            onClick={(status === "err") ? () => this.reconnect() : null}
            role={(status === "err") ? "button" : undefined}

          >
            <strong style={{color: "white"}}>
              {
                (status === "try")
                  && <Spinner animation="border" size="sm" className="me-1"/>
              }
              {(status === "try") && "Reconnecting"}
              {(status === "err") && "Reconnect"}
            </strong>
          </Toast.Body>
        </Toast>
      </ToastContainer>
    )
  };

  render() {
    return (
      <React.Fragment>
        {this.rmModal()}
        <div className="m-3 d-flex justify-content-center">
          <Card style={{maxWidth: "50rem", width: "100%"}}>
            <Tabs defaultActiveKey="cue" className="fs-2">
              <Tab eventKey="cue" title="cue">
                <BottomScrollListener onBottom={()=>this.moreEntries()}>
                  {(scrollRef) =>
                    <Stack gap={5} className="m-3 d-flex">
                      {this.newItem()}
                      {this.state.items.map(e => this.printItem(i))}
                    </Stack>
                  }
                </BottomScrollListener>
              </Tab>
              <Tab eventKey="search" title="Date">
                <Stack gap={5} className="m-3 d-flex">
                  {this.searcher()}
                  {this.state.results.map(i => this.printItem(i))}
                </Stack>
              </Tab>
              <Tab eventKey="tagsearch" title="Notebook"> // new tab
                <Stack gap={5} className="m-3 d-flex">
                  {this.tagsearcher()}
                  {this.state.results.map(i => this.printItem(i))}
                </Stack>
              </Tab>
            </Tabs>
            {this.status()}
          </Card>
        </div>
      </React.Fragment>
    )
  }
}

  export const newItem = () => { //this is defining the type for the form
    const form = useForm({
      defaultValues: {
        title: '',
        link: '',
        tag: '',
        done: [],// bool?
        share: [] //bool
      }
    });

  return ( // this is adding new w form
    <div className='w-full space-y-6 m-auto'>
      <header>
        <h1 className='text-2xl font-semibold'>Add Item</h1>
      </header>
      <FormProvider {...form}>
        <form onSubmit={submitNew(onSubmit)}>
          <div className='flex w-full space-x-6'>
            <div className='flex-1 space-y-3'>
              <div>
                <label htmlFor='title' className='text-sm font-semibold'>Title</label>
                <div className='flex items-center space-x-2'>
                  <input {...register('title', { required: true, maxLength: 77 })} className='flex-1 w-full py-1 px-2 bg-fawn/30 focus:outline-none focus:ring-2 ring-lavender rounded-lg border border-fawn/30' placeholder='title'/>                  
                </div>
              </div>
              <div className='flex items-center space-x-6'>
                <div className='flex-1 space-y-3'>
                  <div>
                    <label htmlFor='link' className='text-sm font-semibold'>Link</label>
                    <input type="url" {...register('link', { required: true, maxLength: 1024 })} className='flex-1 w-full py-1 px-2 bg-fawn/30 focus:outline-none focus:ring-2 ring-lavender rounded-lg border border-fawn/30' placeholder='web+urbitgraph or Earth URL' />
                    <ErrorMessage className='mt-1' field="link" messages={errorMessages(1024)} />
                  </div>
                </div>
              </div>
              <div>
                <label className='text-sm font-semibold'>notebook</label>
                <input {...register('tags', { required: true, maxLength: 77 })} className='flex-1 w-full py-1 px-2 bg-fawn/30 focus:outline-none focus:ring-2 ring-lavender rounded-lg border border-fawn/30' placeholder='notebook'/>                  
              </div>
              <div>
                <label className='text-sm font-semibold'>read</label>
                <input {...register('done')} type="checkbox" value='done'/>                  
              </div>
              <div>
                <label className='text-sm font-semibold'>public</label>
                <input {...register('share')} type="checkbox" value='share'/>                  
              </div>
              <div className='pt-3'>
                <div className='flex justify-between border-t border-zinc-300 py-3'>
                  <button type="submit" className='flex items-center rounded-lg text-base font-semibold text-linen bg-rosy border-2 border-transparent hover:border-linen/60 leading-none py-2 px-3 transition-colors'>
                    Submit
                  </button>
                </div>
              </div>
            </div>
          </div>
        </form>
      </FormProvider>
    </div>
  )
}

const onSubmit = useCallback((values: Omit<PostForm, 'tags'>) => {
  api.poke<Declare>({
    app: 'cue',
    mark: 'add',
    json: {
      post: {
        ...values,
      }
    }
  })
  reset();
});

useEffect(() => {
  register('type')
}, []);

}
export default App;